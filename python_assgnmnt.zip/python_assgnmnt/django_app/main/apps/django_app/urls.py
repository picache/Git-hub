from django.conf.urls import url #added
from . import views #added

urlpatterns = [
    url(r'^$', views.index) #added lines 5-10
    url(r'^new$', views.new)
    url(r'^create$', views.create)
    url(r'^(?P<blog_id>\d+)$', views.show),
    url(r'^(?P<blog_id>\d+)/edit$', views.edit)
    url(r'^(?P<blog_id>\d+/delete$',views.delete)
]